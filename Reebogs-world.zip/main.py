def turn_around():
    turn_left()
    turn_left()
    turn_left()

def turn_right():
    move()
    turn_around()
    
    
def main():    
    move()
    turn_left()
    move()
    turn_around()
    turn_right()
    move()
    turn_left()
    
    
for i in range(0,6):  
    main()